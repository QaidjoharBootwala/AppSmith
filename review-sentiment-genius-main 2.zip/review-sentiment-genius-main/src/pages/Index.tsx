import { useState } from "react";
import { ReviewForm } from "@/components/ReviewForm";
import { ReviewList } from "@/components/ReviewList";
import { analyzeSentiment, type Rating } from "@/utils/sentimentAnalysis";

const Index = () => {
  const [reviews, setReviews] = useState<Rating[]>([]);

  const handleSubmitReview = (name: string, review: string) => {
    const newRating = analyzeSentiment(name, review);
    setReviews((prev) => [newRating, ...prev]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container py-8">
        <h1 className="text-4xl font-bold text-center mb-8 text-primary">
          Consumer Review Analysis
        </h1>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Submit a Review</h2>
            <ReviewForm onSubmit={handleSubmitReview} />
          </div>
          
          <div>
            <h2 className="text-2xl font-semibold mb-4">Review History</h2>
            <ReviewList reviews={reviews} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;