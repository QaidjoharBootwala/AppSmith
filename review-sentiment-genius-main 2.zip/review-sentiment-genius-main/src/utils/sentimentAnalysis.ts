export interface Rating {
  customerName: string;
  rating: number;
  review: string;
  timestamp: Date;
}

// Function to calculate sentiment polarity similar to TextBlob
const calculatePolarity = (text: string): number => {
  const words = text.toLowerCase().split(/\s+/);
  
  // Common positive and negative words with their polarity scores
  const sentimentScores: Record<string, number> = {
    // Strongly positive words (0.8)
    'excellent': 0.8,
    'amazing': 0.8,
    'outstanding': 0.8,
    'fantastic': 0.8,
    
    // Moderately positive words (0.6)
    'good': 0.6,
    'great': 0.6,
    'delicious': 0.6,
    'friendly': 0.6,
    'helpful': 0.6,
    'clean': 0.6,
    
    // Slightly positive words (0.3)
    'nice': 0.3,
    'okay': 0.3,
    'fine': 0.3,
    
    // Slightly negative words (-0.3)
    'mediocre': -0.3,
    'average': -0.3,
    'slow': -0.3,
    
    // Moderately negative words (-0.6)
    'bad': -0.6,
    'poor': -0.6,
    'dirty': -0.6,
    'rude': -0.6,
    
    // Strongly negative words (-0.8)
    'terrible': -0.8,
    'horrible': -0.8,
    'awful': -0.8,
    'disgusting': -0.8
  };

  let totalPolarity = 0;
  let wordCount = 0;

  words.forEach(word => {
    if (sentimentScores[word] !== undefined) {
      totalPolarity += sentimentScores[word];
      wordCount++;
    }
  });

  // If no sentiment words found, return neutral polarity
  if (wordCount === 0) return 0;
  
  // Return average polarity normalized between -1 and 1
  return totalPolarity / wordCount;
};

// Convert polarity to 1-5 rating scale
const polarityToRating = (polarity: number): number => {
  if (polarity < -0.5) return 1;
  if (polarity < 0) return 2;
  if (polarity < 0.5) return 3;
  if (polarity < 0.75) return 4;
  return 5;
};

export const analyzeSentiment = (customerName: string, review: string): Rating => {
  const polarity = calculatePolarity(review);
  const rating = polarityToRating(polarity);
  
  return {
    customerName,
    rating,
    review,
    timestamp: new Date(),
  };
};