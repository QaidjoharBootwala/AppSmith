import { Card } from "@/components/ui/card";
import { Rating } from "@/utils/sentimentAnalysis";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Star, StarHalf } from "lucide-react";

interface ReviewListProps {
  reviews: Rating[];
}

export const ReviewList = ({ reviews }: ReviewListProps) => {
  const getSentimentColor = (rating: number) => {
    if (rating >= 4) return "text-green-600";
    if (rating >= 3) return "text-yellow-600";
    return "text-red-600";
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="w-4 h-4 fill-current" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="w-4 h-4" />);
    }

    return stars;
  };

  const chartData = reviews.map((review) => ({
    name: review.customerName,
    rating: review.rating,
  }));

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <XAxis dataKey="name" />
            <YAxis domain={[0, 5]} />
            <Tooltip />
            <Bar dataKey="rating" fill="#2563eb" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="space-y-4">
        {reviews.map((review, index) => (
          <Card key={index} className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold">{review.customerName}</h3>
                <p className="text-gray-600 mt-1">{review.review}</p>
              </div>
              <div className={`flex items-center ${getSentimentColor(review.rating)}`}>
                {renderStars(review.rating)}
              </div>
            </div>
            <div className="text-sm text-gray-500 mt-2">
              {new Date(review.timestamp).toLocaleDateString()}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};