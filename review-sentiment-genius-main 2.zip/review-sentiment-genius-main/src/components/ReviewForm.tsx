import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface ReviewFormProps {
  onSubmit: (name: string, review: string) => void;
}

export const ReviewForm = ({ onSubmit }: ReviewFormProps) => {
  const [name, setName] = useState("");
  const [review, setReview] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !review.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    onSubmit(name, review);
    setName("");
    setReview("");
    toast.success("Review submitted successfully!");
  };

  return (
    <Card className="p-6 animate-fadeIn">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium mb-1">
            Your Name
          </label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="John Doe"
            className="w-full"
          />
        </div>
        <div>
          <label htmlFor="review" className="block text-sm font-medium mb-1">
            Your Review
          </label>
          <Textarea
            id="review"
            value={review}
            onChange={(e) => setReview(e.target.value)}
            placeholder="Share your experience..."
            className="w-full h-32"
          />
        </div>
        <Button type="submit" className="w-full">
          Submit Review
        </Button>
      </form>
    </Card>
  );
};